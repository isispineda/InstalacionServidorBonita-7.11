(function() {

  'use strict';

  angular.module('org.bonitasoft.features.user.tasks.list.comments', [
    'org.bonitasoft.common.resources',
    'org.bonitasoft.common.moment',
    'org.bonitasoft.features.user.tasks.app.store',
    'ngToast'
  ]);

})();
