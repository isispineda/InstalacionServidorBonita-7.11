(function() {

  'use strict';

  angular.module('org.bonitasoft.features.user.tasks.filters', [
    'ui.bootstrap.buttons',
    'gettext'
  ]);

})();
