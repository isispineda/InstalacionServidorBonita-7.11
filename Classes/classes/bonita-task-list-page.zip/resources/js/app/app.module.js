(function() {

  'use strict';

  angular.module('org.bonitasoft.portal', [
    'org.bonitasoft.features.user.tasks',
    'angular-growl'
  ]);

})();
